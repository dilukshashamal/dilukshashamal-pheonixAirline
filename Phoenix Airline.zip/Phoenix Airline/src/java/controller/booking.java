/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import model.beanClass;

/**
 *
 * @author DILUKSHA SHAMAL
 */
@WebServlet(name = "booking", urlPatterns = {"/booking"})
public class booking extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
       
    }

    
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
         PrintWriter out = response.getWriter();

        processRequest(request, response);
         String dairport = request.getParameter("Dairport");
         String airport = request.getParameter("Aairport");
         String startdatetime = request.getParameter("sdatetime");
         String enddatetime = request.getParameter("edatetime");
         String adults = request.getParameter("adults");
         String children = request.getParameter("children");
         String vclass = request.getParameter("class");
         String email =request.getParameter("email");
         
       beanClass client = new beanClass();
       
       client.setDairport(dairport);
       client.setAirport(airport);
       client.setStartdatetime(startdatetime);
       client.setEnddatetime(enddatetime);
       client.setAdults(adults);
       client.setChildren(children);
       client.setVclass(vclass);
       client.setEmail(email);
        
         if (client.registerClient()){
            out.println("Registration Success!");
            RequestDispatcher req = request.getRequestDispatcher("index.html");
            req.include(request, response);
        }else{
            out.println("Registation Failed!");
            RequestDispatcher req = request.getRequestDispatcher("index.html");
            req.include(request, response);
        }    
    }

    
}
