/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import model.staff2;

/**
 *
 * @author DILUKSHA SHAMAL
 */
@WebServlet(name = "st2", urlPatterns = {"/st2"})
public class st2 extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        
    }

  
   
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
        PrintWriter out = response.getWriter();
        String name = request.getParameter("name");
         String email = request.getParameter("email");
         String password = request.getParameter("password");
         
        staff2 st2 = new staff2();
       
       st2.setName(name);
       st2.setEmail(email);
       st2.setPassword(password);
       
       if(st2.signUp())
        {
            out.println("<div class='alert alert-success' role='alert'> <b> Registration Success!!! </b> </div>");
            RequestDispatcher rd = request.getRequestDispatcher("sregister2.html");
            rd.include(request, response);
        }
        else{
            out.println("<div class='alert alert-danger' role='alert'> <b> Registration Failed!!!</b> </div>");
            RequestDispatcher rd = request.getRequestDispatcher("sregister2.html");
            rd.include(request, response);
        }
    }

    
}
