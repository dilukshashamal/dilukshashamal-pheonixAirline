/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import model.userreg;

/**
 *
 * @author DILUKSHA SHAMAL
 */
@WebServlet(name = "user", urlPatterns = {"/user"})
public class user extends HttpServlet {

    
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        
    }

    
    
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
        PrintWriter out = response.getWriter();
         String name = request.getParameter("name");
         String email = request.getParameter("email");
         String password = request.getParameter("password");
         
        userreg us = new userreg();
       
       us.setName(name);
       us.setEmail(email);
       us.setPassword(password);
       
       if(us.signUp())
        {
            out.println("<div class='alert alert-success' role='alert'> <b> Sign Up Success!!! </b> </div>");
            RequestDispatcher rd = request.getRequestDispatcher("index.html");
            rd.include(request, response);
        }
        else{
            out.println("<div class='alert alert-danger' role='alert'> <b> Sign Up Failed!!!</b> </div>");
            RequestDispatcher rd = request.getRequestDispatcher("index.html");
            rd.include(request, response);
        }
    }

    
}
