/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import model.staff1;

/**
 *
 * @author DILUKSHA SHAMAL
 */
@WebServlet(name = "st1", urlPatterns = {"/st1"})
public class st1 extends HttpServlet {

   
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        
    }

    
    
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
         PrintWriter out = response.getWriter();
          String name = request.getParameter("name");
         String email = request.getParameter("email");
         String password = request.getParameter("password");
         
        staff1 st1 = new staff1();
       
       st1.setName(name);
       st1.setEmail(email);
       st1.setPassword(password);
       
       if(st1.signUp())
        {
            out.println("<div class='alert alert-success' role='alert'> <b> Registration Success!!! </b> </div>");
            RequestDispatcher rd = request.getRequestDispatcher("sregister.html");
            rd.include(request, response);
        }
        else{
            out.println("<div class='alert alert-danger' role='alert'> <b> Registration Failed!!!</b> </div>");
            RequestDispatcher rd = request.getRequestDispatcher("sregister.html");
            rd.include(request, response);
        }
    }

    
}
