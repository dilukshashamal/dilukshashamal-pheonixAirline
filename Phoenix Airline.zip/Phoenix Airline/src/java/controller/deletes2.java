/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import model.staff2;

/**
 *
 * @author DILUKSHA SHAMAL
 */
@WebServlet(name = "deletes2", urlPatterns = {"/deletes2"})
public class deletes2 extends HttpServlet {

   
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
    }

    
   
    
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
        PrintWriter out = response.getWriter();
        String email = request.getParameter("email");
        
        staff2 s2 = new staff2();
        if(s2.deletest2(email))
        {
            out.println("<div class='alert alert-success col-md-8 offset-2' role='alert'>\n" +
"  Delete Success!!! </div>");
            RequestDispatcher rd = request.getRequestDispatcher("staff2.jsp");
            rd.include(request, response);
        }
        else{
          out.println("<div class='alert alert-danger' role='alert'>\n" +
"  Delete Failed!!!!\n" +
"</div>");
            RequestDispatcher rd = request.getRequestDispatcher("staff2.jsp");
            rd.include(request, response);  
        }
    }

    

}
